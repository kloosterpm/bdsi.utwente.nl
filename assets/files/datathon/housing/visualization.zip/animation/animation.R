library(tidyverse)
library(gganimate)
library(gifski)

train <- readr::read_csv("../data/train.csv")

# prepare some data
animate <- train %>% 
    mutate(DateSold = lubridate::ym(glue::glue("{YrSold}-{MoSold}"))) %>%
    group_by(DateSold, BldgType, Neighborhood) %>%
    summarize(across(c(LotArea, SalePrice), median), Count = n()) %>% 
    filter(LotArea <= 50000) # there's a single row with > 150k area

ggplot(animate,
       aes(
           x = LotArea,
           y = SalePrice,
           size = Count,
           colour = Neighborhood
       )) +
    geom_point(alpha = 0.7, show.legend = FALSE) +
    scale_size(range = c(2, 12)) +
    facet_wrap(. ~ BldgType) +
    
    # animation addons
    labs(title = 'Date sold: {frame_time}', x = 'Median lot size', y = 'Median sale price') +
    transition_time(DateSold) +
    exit_fade() + shadow_wake(.1) +
    ease_aes('linear')
