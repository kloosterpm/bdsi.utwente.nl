#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tidyverse)
library(ggplot2)

train <- readr::read_csv("../data/train.csv")

ui <- fluidPage(
    fluidPage(
        sidebarLayout(
            sidebarPanel(
                selectInput("x", "X-Axis", names(train)),
                selectInput("y", "Y-Axis", names(train)),
                selectInput("geom", "Geom", c("line", "point", "boxplot"))
            ),
            mainPanel(
                plotOutput("plot")
            )
        )
    )
)

server <- function(input, output, session) {
    output$plot <- renderPlot({
        cat(input$x)
        cat(input$y)
        base <- ggplot(train, aes_string(x = input$x, y = input$y))
        
        if(input$geom == "line"){
            plot <- base + geom_line()
        } else if (input$geom == "boxplot") {
            plot <- base + geom_boxplot()
        } else {
            plot <- base + geom_point()
        }
        
        return(plot)
    })
}
# Run the application 
shinyApp(ui = ui, server = server, options = list(test.mode = TRUE))
