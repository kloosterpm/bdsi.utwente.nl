library(tidyverse)
library(shiny)
library(esquisse)

# Load some datasets in app environment
train <- readr::read_csv("../data/train.csv")
test <- readr::read_csv("../data/test.csv")
full <- dplyr::bind_rows(train = train, test = test, .id = "source")

ui <- fluidPage(
    radioButtons(
        "data",
        "Dataset",
        c("training", "testing", "full"),
        "train",
        inline = TRUE
    ),
    esquisse_ui(
        id = "esquisse",
        container = esquisseContainer(height = "auto"),
        header = FALSE
    )
)

server <- function(input, output, session) {
    data_rv <- reactiveValues(data = train, name = "training")
    
    observeEvent(input$data, {
        data_rv$name <- input$data
        data_rv$data <- switch(
            input$data,
            "training" = train,
            "testing" = test,
            "full" = full
        )
    })
    
    esquisse_server(id = "esquisse", data_rv = data_rv)
}

shinyApp(ui, server)
